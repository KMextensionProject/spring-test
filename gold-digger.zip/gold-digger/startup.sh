# These environment variables are required to successfully run the gold-digger app
export COINBASE_API_KEY="tvoj api kluc / public key"
export COINBASE_API_SECRET="tvoj secret / private key"
export COINBASE_API_PASSPHRASE="tvoja fraza"
export POLYGON_API_KEY="tvoj polygon api kluc"

# This environment variable is optional and can represent email address or 
# phone number or some other communication destination (email is predefined)
export NOTIFICATION_RECIPIENT="tvoj email (bud tu nechaj prazdne uvodzovky alebo zadaj svoj mail)"

SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
FILE=$SCRIPT_DIR"/apache-tomcat-9.0.43/logs/app.log"

# Starts the script that launches tomcat server with unwrapped gold-digger app
$SCRIPT_DIR"/apache-tomcat-9.0.43/bin/startup.sh"

# Removes log file if it exists before new server launch
# Then creates the log file in order to tail it without error
[ -f $FILE ] && rm $FILE
touch $FILE
tail -f $FILE
